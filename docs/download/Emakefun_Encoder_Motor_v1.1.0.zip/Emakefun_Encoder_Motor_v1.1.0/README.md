# Emakefun Encoder Motor

[![Arduino ESP32 Build](https://github.com/emakefun-arduino-library/em_esp32_encoder_motor/actions/workflows/arduino_esp32_build.yml/badge.svg)](https://github.com/emakefun-arduino-library/em_esp32_encoder_motor/actions/workflows/arduino_esp32_build.yml)

## Page

<https://emakefun-arduino-library.github.io/em_esp32_encoder_motor/>
